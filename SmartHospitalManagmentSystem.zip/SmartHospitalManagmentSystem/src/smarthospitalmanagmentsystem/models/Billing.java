package smarthospitalmanagmentsystem.models;

import java.time.LocalDate;

public class Billing {

    private String billingId;
    private Patient patient;
    private String serviceType; // Example: Consultation, Surgery, Lab Test
    private double amount;
    private LocalDate billingDate;

    public Billing(String billingId, Patient patient, String serviceType, double amount, LocalDate billingDate) {
        this.billingId = billingId;
        this.patient = patient;
        this.serviceType = serviceType;
        this.amount = amount;
        this.billingDate = billingDate;
    }

    // Getters
    public String getBillingId() {
        return billingId;
    }

    public Patient getPatient() {
        return patient;
    }

    public String getServiceType() {
        return serviceType;
    }

    public double getAmount() {
        return amount;
    }

    public LocalDate getBillingDate() {
        return billingDate;
    }

    // Setters
    public void setBillingId(String billingId) {
        this.billingId = billingId;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    public void setServiceType(String serviceType) {
        this.serviceType = serviceType;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public void setBillingDate(LocalDate billingDate) {
        this.billingDate = billingDate;
    }

    @Override
    public String toString() {
        return "Billing{"
                + "billingId='" + billingId + '\''
                + ", patient=" + patient.getName()
                + ", serviceType='" + serviceType + '\''
                + ", amount=" + amount
                + ", billingDate=" + billingDate
                + '}';
    }
}
