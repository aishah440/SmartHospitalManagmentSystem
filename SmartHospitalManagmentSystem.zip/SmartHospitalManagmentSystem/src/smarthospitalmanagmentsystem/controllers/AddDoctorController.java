package smarthospitalmanagmentsystem.controllers;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import smarthospitalmanagmentsystem.DB.DatabaseConnection;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class AddDoctorController {

    private Stage stage;
    private Scene scene;
    private Parent root;

    @FXML
    private TextField txtDoctorId;

    @FXML
    private TextField txtDoctorName;

    @FXML
    private ComboBox<String> comboSpecialization;

    @FXML
    private Button btnAdd;

    @FXML
    private Button btnBack;

    @FXML
    public void initialize() {
        comboSpecialization.getItems().addAll("Cardiologist", "Dermatologist", "Neurologist", "Pediatrician", "General Practitioner");
    }

    @FXML
    private void handleAdd() {
        String doctorId = txtDoctorId.getText().trim();
        String doctorName = txtDoctorName.getText().trim();
        String specialization = comboSpecialization.getValue();

        if (doctorId.isEmpty() || doctorName.isEmpty() || specialization == null) {
            showAlert("Validation Error", "Please fill in all fields.");
            return;
        }

        try {
            int id = Integer.parseInt(doctorId);
            addDoctor(id, doctorName, specialization);
            showAlert("Success", "Doctor added successfully.");
            clearFields();
        } catch (NumberFormatException e) {
            showAlert("Error", "Doctor ID must be a number.");
        } catch (SQLException e) {
            showAlert("Database Error", e.getMessage());
        }
    }

    private void addDoctor(int doctorId, String doctorName, String specialization) throws SQLException {
        String userSql = "INSERT INTO users (id, name, password, userType) VALUES (?, ?, ?, ?)";
        String doctorSql = "INSERT INTO doctors (id, name, specialization) VALUES (?, ?, ?)";

        String defaultPassword = "doctor123" + doctorId; // unique base
        String hashedPassword = hashPassword(defaultPassword); // Hash the password

        try ( Connection conn = DatabaseConnection.getInstance().getConnection()) {
            conn.setAutoCommit(false); // Begin transaction

            try ( PreparedStatement userStmt = conn.prepareStatement(userSql);  PreparedStatement doctorStmt = conn.prepareStatement(doctorSql)) {

                // Insert into users
                userStmt.setInt(1, doctorId);
                userStmt.setString(2, doctorName);
                userStmt.setString(3, hashedPassword);
                userStmt.setString(4, "Doctor");
                userStmt.executeUpdate();

                // Insert into doctors
                doctorStmt.setInt(1, doctorId);
                doctorStmt.setString(2, doctorName);
                doctorStmt.setString(3, specialization);
                doctorStmt.executeUpdate();

                conn.commit(); // Commit if all goes well
            } catch (SQLException e) {
                conn.rollback(); // Rollback on error
                throw e;
            } finally {
                conn.setAutoCommit(true); // Restore auto-commit
            }
        }
    }

    private String generateDefaultPassword() {
        String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        SecureRandom random = new SecureRandom();
        StringBuilder password = new StringBuilder();
        for (int i = 0; i < 10; i++) {
            password.append(chars.charAt(random.nextInt(chars.length())));
        }
        return password.toString();
    }

    private String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hashedBytes = md.digest(password.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : hashedBytes) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Error hashing password", e);
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void clearFields() {
        txtDoctorId.clear();
        txtDoctorName.clear();
        comboSpecialization.setValue(null);
    }

    @FXML
    private void handleBack(ActionEvent event) throws IOException {
        Node source = (Node) event.getSource();
        Stage stage = (Stage) source.getScene().getWindow();
        stage.close();
    }
}
