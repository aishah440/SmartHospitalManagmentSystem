package smarthospitalmanagmentsystem.models;

public class Doctor extends User {

    private String specialization;

    public Doctor(String id, String name) {
        super(id, name);
    }
     
    
    public Doctor(String id, String name, String specialization) {
        super(id, name);
        this.specialization = specialization;
    }

    public String getSpecialization() {
        return specialization;
    }

    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }

}
