package smarthospitalmanagmentsystem.controllers;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.Parent;
import javafx.scene.Node;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.*;
import java.util.*;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.event.ActionEvent;
import javafx.scene.layout.AnchorPane;

import smarthospitalmanagmentsystem.DB.DatabaseConnection;
import smarthospitalmanagmentsystem.models.Patient;
import smarthospitalmanagmentsystem.models.Prescription;

public class PatientRecordsController {

    private Stage stage;
    private Scene scene;
    private Parent root;

    @FXML
    private TableView<Patient> tableView;
    @FXML
    private TableColumn<Patient, String> colPatientID;
    @FXML
    private TableColumn<Patient, String> colPatientName;
    @FXML
    private TableColumn<Patient, String> colMedicalCondition;
    @FXML
    private TableColumn<Patient, String> colCurrentMedications;
    @FXML
    private TableColumn<Patient, String> colPrescription;
    @FXML
    private TextField searchField;

    private final ObservableList<Patient> patientList = FXCollections.observableArrayList();

    private String doctorId;

    public void setDoctorId(String id) {
        this.doctorId = id;
        loadAllPatients();
    }

    @FXML
    public void initialize() {
        colPatientID.setCellValueFactory(data -> new ReadOnlyStringWrapper(data.getValue().getId()));
        colPatientName.setCellValueFactory(data -> new ReadOnlyStringWrapper(data.getValue().getName()));
        colMedicalCondition.setCellValueFactory(data -> new ReadOnlyStringWrapper(data.getValue().getMedicalCondition()));
        colCurrentMedications.setCellValueFactory(data -> new ReadOnlyStringWrapper(data.getValue().getCurrentMedications()));
        colPrescription.setCellValueFactory(data -> {
            if (!data.getValue().getPrescriptions().isEmpty()) {
                return new ReadOnlyStringWrapper(data.getValue().getPrescriptions().get(0).getPrescription());
            } else {
                return new ReadOnlyStringWrapper("No prescriptions");
            }
        });
    }

    public void loadAllPatients() {
        patientList.clear();

        String query = """
            SELECT DISTINCT p.patient_id, p.patient_name, p.medical_condition, p.current_medications,
                pr.prescription
            FROM patients p
            LEFT JOIN (
                SELECT patient_id, prescription
                FROM prescriptions
                WHERE (patient_id, created_at) IN (
                    SELECT patient_id, MAX(created_at)
                    FROM prescriptions
                    GROUP BY patient_id
                )
            ) pr ON p.patient_id = pr.patient_id
            WHERE p.patient_id IN (
                SELECT patient_id FROM appointments WHERE doctor_id = ?
                UNION
                SELECT patient_id FROM prescriptions WHERE doctor_id = ?
            )
        """;

        try ( Connection conn = DatabaseConnection.getInstance().getConnection();  PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, doctorId);
            stmt.setString(2, doctorId);

            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Patient patient = new Patient(
                        rs.getString("patient_id"),
                        rs.getString("patient_name"),
                        rs.getString("medical_condition"),
                        rs.getString("current_medications")
                );

                String prescriptionText = rs.getString("prescription");
                if (prescriptionText != null) {
                    patient.addPrescription(new Prescription(prescriptionText));
                }

                patientList.add(patient);
            }

            tableView.setItems(patientList);

        } catch (SQLException e) {
            showAlert("Database Error", "Unable to load patients: " + e.getMessage());
        }
    }

    @FXML
    private void onSearchClicked() {
        String id = searchField.getText().trim();
        if (id.isEmpty()) {
            loadAllPatients();
            return;
        }

        String query = """
                SELECT p.patient_id, p.patient_name, p.medical_condition, p.current_medications, r.prescription
                FROM patients p
                LEFT JOIN prescriptions r ON p.patient_id = r.patient_id
                WHERE p.patient_id = ?
                """;

        patientList.clear();

        try ( Connection conn = DatabaseConnection.getInstance().getConnection();  PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, id);
            ResultSet rs = stmt.executeQuery();

            Patient patient = null;

            while (rs.next()) {

                patient = new Patient(
                        rs.getString("patient_id"),
                        rs.getString("patient_name"),
                        rs.getString("medical_condition"),
                        rs.getString("current_medications")
                );

                String pres = rs.getString("prescription");
                if (pres != null) {
                    patient.addPrescription(new Prescription(pres));
                }

                patientList.add(patient);

            }

            tableView.setItems(patientList);

        } catch (SQLException e) {
            showAlert("Search Failed", e.getMessage());
        }
    }

    @FXML
    private void handleUpdatePatient() {
        Patient selected = tableView.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("Selection Error", "Please select a patient.");
            return;
        }

        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/smarthospitalmanagmentsystem/views/UpdatePatientHistory.fxml"));
            Parent root = loader.load();
            UpdatePatienthistoryController controller = loader.getController();
            controller.initializeWithPatient(selected, this, doctorId);

            Stage stage = (Stage) tableView.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();

        } catch (IOException e) {
            showAlert("UI Error", "Could not load update screen.");
        }
    }

    @FXML
    private void handleBack(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/smarthospitalmanagmentsystem/views/DoctorPage.fxml"));
        Parent root = loader.load();

        DoctorPageController controller = loader.getController();
        controller.setDoctorId(doctorId);

        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }

    private void showAlert(String title, String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setContentText(msg);
        alert.showAndWait();
    }
}
