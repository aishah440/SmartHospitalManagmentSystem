package smarthospitalmanagmentsystem.controllers;

import java.io.IOException;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.Node;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import smarthospitalmanagmentsystem.DB.DatabaseConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class PrescriptionmanagementScreeController {

    private Stage stage;
    private Scene scene;
    private Parent root;

    @FXML
    private ComboBox<String> patientComboBox;

    @FXML
    private TextArea prescriptionTextArea;

    @FXML
    private Button backButton;

    private String doctorId;

    @FXML
    public void initialize() {
        // Nothing here initially - doctorId must be set first
    }

    public void setDoctorId(String doctorId) {
        this.doctorId = doctorId;
        loadPatients();
    }

    private void loadPatients() {
        String sql = """
        SELECT DISTINCT p.patient_name
        FROM patients p
        JOIN appointments a ON p.patient_id = a.patient_id
        WHERE a.doctor_id = ?
    """;

        patientComboBox.getItems().clear();

        try ( Connection conn = DatabaseConnection.getInstance().getConnection();  PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, doctorId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                patientComboBox.getItems().add(rs.getString("patient_name"));
            }

        } catch (SQLException e) {
            showAlert("Error Loading Patients", e.getMessage());
        }
    }

    @FXML
    private void savePrescription() {
        String patient = patientComboBox.getValue();
        String prescription = prescriptionTextArea.getText().trim();

        if (patient == null || prescription.isEmpty()) {
            showAlert("Validation Error", "Please select a patient and enter prescription details.");
            return;
        }

        String patientId = getPatientId(patient);

        if (patientId == null) {
            showAlert("Error", "Patient not found.");
            return;
        }

        String sql = "INSERT INTO prescriptions (patient_id, prescription, doctor_id) VALUES (?, ?, ?)";

        try ( Connection conn = DatabaseConnection.getInstance().getConnection();  PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, patientId);
            pstmt.setString(2, prescription);
            pstmt.setString(3, doctorId);
            pstmt.executeUpdate();

            showAlert("Success", "Prescription saved successfully.");
            prescriptionTextArea.clear();
            loadPatients(); // Optional: reload to reflect new data

        } catch (SQLException e) {
            showAlert("Database Error", e.getMessage());
        }
    }

    private String getPatientId(String patientName) {
        String sql = "SELECT patient_id FROM patients WHERE patient_name = ?";

        try ( Connection conn = DatabaseConnection.getInstance().getConnection();  PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, patientName);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return rs.getString("patient_id");
            }

        } catch (SQLException e) {
            showAlert("Error Fetching Patient ID", e.getMessage());
        }

        return null;
    }

    @FXML
    private void handleBack(javafx.event.ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/smarthospitalmanagmentsystem/views/DoctorPage.fxml"));
        Parent root = loader.load();

        DoctorPageController controller = loader.getController();
        controller.setDoctorId(doctorId);  // Re-pass the ID

        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
