package smarthospitalmanagmentsystem.controllers;

import java.io.IOException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import smarthospitalmanagmentsystem.models.Reminder;
import smarthospitalmanagmentsystem.DB.DatabaseConnection;

import java.sql.*;
import java.time.LocalDate;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class CreateReminderController {

    private Stage stage;
    private Scene scene;
    private Parent root;

    @FXML
    private TextField reminderTitleField;

    @FXML
    private TextArea reminderDescriptionField;

    @FXML
    private DatePicker reminderDatePicker;

    @FXML
    private TableView<Reminder> reminderTable;

    @FXML
    private TableColumn<Reminder, String> titleColumn;

    @FXML
    private TableColumn<Reminder, String> descriptionColumn;

    @FXML
    private TableColumn<Reminder, LocalDate> dateColumn;

    @FXML
    private Button cancelButton;

    private String patientId;

    public void setPatientId(String id) {
        this.patientId = id;
        handleDisplayReminders();
    }

    public void initialize() {
        titleColumn.setCellValueFactory(new PropertyValueFactory<>("title"));
        descriptionColumn.setCellValueFactory(new PropertyValueFactory<>("description"));
        dateColumn.setCellValueFactory(new PropertyValueFactory<>("reminderDate"));
    }

    @FXML
    private void handleSetReminder() {
        String title = reminderTitleField.getText();
        String description = reminderDescriptionField.getText();
        LocalDate date = reminderDatePicker.getValue();

        if (title.isEmpty() || description.isEmpty() || date == null || patientId == null) {
            Alert alert = new Alert(Alert.AlertType.ERROR, "All fields must be filled in!");
            alert.show();
            return;
        }

        String sql = "INSERT INTO reminders (title, description, reminder_date, patient_id) VALUES (?, ?, ?, ?)";

        try ( Connection conn = DatabaseConnection.getInstance().getConnection();  PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, title);
            stmt.setString(2, description);
            stmt.setDate(3, Date.valueOf(date));
            stmt.setString(4, patientId);

            stmt.executeUpdate();
            Alert alert = new Alert(Alert.AlertType.INFORMATION, "Reminder Set!");
            alert.show();
            

        } catch (SQLException e) {
            e.printStackTrace();
            Alert alert = new Alert(Alert.AlertType.ERROR, "Error setting reminder!");
            alert.show();
        }
    }

    @FXML
    private void handleDisplayReminders() {
        if (patientId == null) {
            return;
        }

        ObservableList<Reminder> reminders = FXCollections.observableArrayList();
        String query = "SELECT * FROM reminders WHERE patient_id = ?";

        try ( Connection conn = DatabaseConnection.getInstance().getConnection();  PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, patientId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                reminders.add(new Reminder(
                        rs.getInt("id"),
                        rs.getString("title"),
                        rs.getString("description"),
                        rs.getDate("reminder_date").toLocalDate(),
                        rs.getString("patient_id")
                ));
            }

            reminderTable.setItems(reminders);

        } catch (SQLException e) {
            e.printStackTrace();
            Alert alert = new Alert(Alert.AlertType.ERROR, "Error displaying reminders!");
            alert.show();
        }
    }

    @FXML
    private void handleCancel(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/smarthospitalmanagmentsystem/views/Patient page.fxml"));
        Parent root = loader.load();

        // Pass patientId back to PatientPageController
        PatientPageController controller = loader.getController();
        controller.setPatientId(patientId);

        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }
}
