package smarthospitalmanagmentsystem.controllers;

import java.io.IOException;
import java.sql.*;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import smarthospitalmanagmentsystem.DB.DatabaseConnection;
import smarthospitalmanagmentsystem.models.Patient;

import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.time.LocalDate;

public class ScheduleConsultationController {

    private Stage stage;
    private Scene scene;
    private Parent root;

    @FXML
    private TextField txtTime;
    @FXML
    private DatePicker datePicker;
    @FXML
    private TextField txtPrice;
    @FXML
    private TextArea txtDescription;
    @FXML
    private ComboBox<Patient> comboPatient;

    private String doctorId;

    @FXML
    public void initialize() {
        loadPatients();
        setupPatientComboBox();
    }

    public void setDoctorId(String doctorId) {
        this.doctorId = doctorId;
    }

    private void loadPatients() {
        String sql = "SELECT patient_id, patient_name FROM patients";

        try ( Connection conn = DatabaseConnection.getInstance().getConnection();  PreparedStatement stmt = conn.prepareStatement(sql);  ResultSet rs = stmt.executeQuery()) {

            comboPatient.getItems().clear();

            while (rs.next()) {
                Patient patient = new Patient(
                        rs.getString("patient_id"),
                        rs.getString("patient_name")
                );
                comboPatient.getItems().add(patient);
            }

        } catch (SQLException e) {
            showAlert("Database Error", "Failed to load patients.\n" + e.getMessage());
        }
    }

    private void setupPatientComboBox() {
        comboPatient.setCellFactory(lv -> new ListCell<>() {
            @Override
            protected void updateItem(Patient patient, boolean empty) {
                super.updateItem(patient, empty);
                setText(empty || patient == null ? null : patient.getName());
            }
        });

        comboPatient.setButtonCell(new ListCell<>() {
            @Override
            protected void updateItem(Patient patient, boolean empty) {
                super.updateItem(patient, empty);
                setText(empty || patient == null ? null : patient.getName());
            }
        });
    }

    @FXML
    private void scheduleConsultation() {
        Patient selectedPatient = comboPatient.getValue();
        String time = txtTime.getText().trim();
        LocalDate date = datePicker.getValue();
        String priceStr = txtPrice.getText().trim();
        String description = txtDescription.getText().trim();

        if (selectedPatient == null || time.isEmpty() || date == null || priceStr.isEmpty() || description.isEmpty()) {
            showAlert("Validation Error", "Please fill in all fields.");
            return;
        }

        double price;
        try {
            price = Double.parseDouble(priceStr);
        } catch (NumberFormatException e) {
            showAlert("Input Error", "Price must be a valid number.");
            return;
        }

        String sql = "INSERT INTO consultations (patient_id, consultation_time, consultation_date, price, description, doctor_id) VALUES (?, ?, ?, ?, ?, ?)";

        try ( Connection conn = DatabaseConnection.getInstance().getConnection();  PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, selectedPatient.getId());
            pstmt.setString(2, time);
            pstmt.setDate(3, Date.valueOf(date));
            pstmt.setDouble(4, price);
            pstmt.setString(5, description);
            pstmt.setString(6, doctorId); // Pass doctorId here
            pstmt.executeUpdate();

            insertBillingRecord(selectedPatient.getId(), "Consultation", price, date);

            showAlert("Success", "Consultation scheduled successfully.");
            clearFields();

        } catch (SQLException e) {
            showAlert("Database Error", e.getMessage());
        }
    }

    private void insertBillingRecord(String patientId, String serviceType, double amount, LocalDate billingDate) {
        String billingQuery = "INSERT INTO billing (patient_id, service_type, amount, billing_date) VALUES (?, ?, ?, ?)";

        try ( Connection conn = DatabaseConnection.getInstance().getConnection();  PreparedStatement billingStmt = conn.prepareStatement(billingQuery)) {

            billingStmt.setString(1, patientId);
            billingStmt.setString(2, serviceType);
            billingStmt.setDouble(3, amount);
            billingStmt.setDate(4, Date.valueOf(billingDate));
            billingStmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void cancel(javafx.event.ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/smarthospitalmanagmentsystem/views/DoctorPage.fxml"));
        Parent root = loader.load();

        DoctorPageController controller = loader.getController();
        controller.setDoctorId(doctorId);  // Re-pass the ID

        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }

    private void clearFields() {
        comboPatient.setValue(null);
        txtTime.clear();
        datePicker.setValue(null);
        txtPrice.clear();
        txtDescription.clear();
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }

    public void refreshPatients() {
        loadPatients();
    }
}
