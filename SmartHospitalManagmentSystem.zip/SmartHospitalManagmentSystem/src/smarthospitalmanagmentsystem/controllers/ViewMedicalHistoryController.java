package smarthospitalmanagmentsystem.controllers;

import java.io.IOException;
import java.sql.*;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.control.cell.PropertyValueFactory;
import smarthospitalmanagmentsystem.DB.DatabaseConnection;
import smarthospitalmanagmentsystem.models.Patient;

public class ViewMedicalHistoryController implements Initializable {

    private Stage stage;
    private Scene scene;
    private Parent root;

    private String patientId;

    @FXML
    private TableView<Patient> medicalHistoryTable;
    @FXML
    private TableColumn<Patient, String> colPatientId;
    @FXML
    private TableColumn<Patient, String> colPatientName;
    @FXML
    private TableColumn<Patient, String> colMedicalCondition;
    @FXML
    private TableColumn<Patient, String> colCurrentMedications;
    @FXML
    private TextField txtPatientId;
    @FXML
    private Button cancelBtn;

    private ObservableList<Patient> patientList = FXCollections.observableArrayList();

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        colPatientId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colPatientName.setCellValueFactory(new PropertyValueFactory<>("name"));
        colMedicalCondition.setCellValueFactory(new PropertyValueFactory<>("medicalCondition"));
        colCurrentMedications.setCellValueFactory(new PropertyValueFactory<>("currentMedications"));
    }

    public void setPatientId(String id) {
        this.patientId = id;
        txtPatientId.setText(id);
        txtPatientId.setDisable(true);
        onViewClicked(); // auto load history
    }

    @FXML
    private void onViewClicked() {
        String patientIdInput = txtPatientId.getText().trim();

        if (patientIdInput.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Please enter a Patient ID.");
            return;
        }

        patientList.clear();

        String query = "SELECT patient_id, patient_name, medical_condition, current_medications FROM patients WHERE patient_id = ?";

        try ( Connection conn = DatabaseConnection.getInstance().getConnection();  PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, patientIdInput);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Patient p = new Patient(
                        rs.getString("patient_id"),
                        rs.getString("patient_name"),
                        rs.getString("medical_condition"),
                        rs.getString("current_medications")
                );
                patientList.add(p);
            }

            medicalHistoryTable.setItems(patientList);

        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Error retrieving medical history: " + e.getMessage());
        }
    }

    @FXML
    private void onBackButtonClicked(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/smarthospitalmanagmentsystem/views/Patient page.fxml"));
        Parent root = loader.load();

        PatientPageController controller = loader.getController();
        controller.setPatientId(patientId); // re-pass patient ID

        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    private void showAlert(Alert.AlertType type, String message) {
        Alert alert = new Alert(type);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
