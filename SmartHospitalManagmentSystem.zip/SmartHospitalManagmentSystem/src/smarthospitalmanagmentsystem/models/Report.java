package smarthospitalmanagmentsystem.models;

import java.sql.Date;

public class Report {

    private int id;
    private String reportType;
    private String message;
    private Date reportDate;

    public Report(int id, String reportType, String message, Date reportDate) {
        this.id = id;
        this.reportType = reportType;
        this.message = message;
        this.reportDate = reportDate;
    }

    // Getters
    public int getId() {
        return id;
    }

    public String getReportType() {
        return reportType;
    }

    public String getMessage() {
        return message;
    }

    public Date getReportDate() {
        return reportDate;
    }
}
