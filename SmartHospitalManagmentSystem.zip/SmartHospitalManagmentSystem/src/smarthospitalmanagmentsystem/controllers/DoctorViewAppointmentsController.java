package smarthospitalmanagmentsystem.controllers;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.scene.Node;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import smarthospitalmanagmentsystem.DB.DatabaseConnection;
import smarthospitalmanagmentsystem.models.Appointment;
import smarthospitalmanagmentsystem.models.Patient;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.time.LocalDate;
import java.util.ResourceBundle;

public class DoctorViewAppointmentsController implements Initializable {

    @FXML
    private TableView<Appointment> appointmentsTable;
    @FXML
    private TableColumn<Appointment, String> patientNameCol;
    @FXML
    private TableColumn<Appointment, LocalDate> dateCol;
    @FXML
    private TableColumn<Appointment, String> timeCol;
    @FXML
    private TableColumn<Appointment, Double> priceCol;
    @FXML
    private TableColumn<Appointment, String> titleCol;

    private String doctorId;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        patientNameCol.setCellValueFactory(data
                -> new javafx.beans.property.SimpleStringProperty(
                        data.getValue().getPatient() != null ? data.getValue().getPatient().getName() : ""
                ));
        dateCol.setCellValueFactory(new PropertyValueFactory<>("date"));
        timeCol.setCellValueFactory(new PropertyValueFactory<>("time"));
        priceCol.setCellValueFactory(new PropertyValueFactory<>("price"));
        titleCol.setCellValueFactory(new PropertyValueFactory<>("title"));
    }

    public void setDoctorId(String id) {
        this.doctorId = id;
        loadAppointments();
    }

    private void loadAppointments() {
        if (doctorId == null || doctorId.isEmpty()) {
            return;
        }

        ObservableList<Appointment> appointments = FXCollections.observableArrayList();
        String query = """
            SELECT a.date, a.time, a.price, a.title, p.patient_name
            FROM appointments a
            JOIN patients p ON p.patient_id = a.patient_id
            WHERE a.doctor_id = ?
        """;

        try ( Connection conn = DatabaseConnection.getInstance().getConnection();  PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, doctorId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                String patientName = rs.getString("patient_name");
                LocalDate date = rs.getDate("date").toLocalDate();
                String time = rs.getString("time");
                double price = rs.getDouble("price");
                String title = rs.getString("title");

                Patient patient = new Patient(null, patientName);  // Only name needed
                appointments.add(new Appointment(patient, date, time, price, title));
            }

            appointmentsTable.setItems(appointments);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleBack(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/smarthospitalmanagmentsystem/views/DoctorPage.fxml"));
        Parent root = loader.load();

        DoctorPageController controller = loader.getController();
        controller.setDoctorId(doctorId);

        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }
}
