
package smarthospitalmanagmentsystem.models;

import java.time.LocalDate;

public class EmergencyAlert {
    private int id;
    private String alertType;
    private String message;
    private LocalDate reportDate;

    public EmergencyAlert(int id, String alertType, String message, LocalDate reportDate) {
        this.id = id;
        this.alertType = alertType;
        this.message = message;
        this.reportDate = reportDate;
    }

    public EmergencyAlert(String alertType, String message) {
        this.alertType = alertType;
        this.message = message;
        this.reportDate = LocalDate.now(); // default to current date
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public String getAlertType() {
        return alertType;
    }

    public void setAlertType(String alertType) {
        this.alertType = alertType;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public LocalDate getReportDate() {
        return reportDate;
    }

    public void setReportDate(LocalDate reportDate) {
        this.reportDate = reportDate;
    }
}