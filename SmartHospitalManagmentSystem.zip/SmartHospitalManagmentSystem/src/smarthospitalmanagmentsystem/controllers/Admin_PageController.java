package smarthospitalmanagmentsystem.controllers;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author AESHAH
 */
public class Admin_PageController implements Initializable {

    private Stage stage;
    private Scene scene;
    private Parent root;

    @FXML
    private Button manageDoctorsButton;
    @FXML
    private Button managePatientsButton;
    @FXML
    private Button generateReportsButton;
    @FXML
    private Button sosButton;
    
    @FXML
    private Button backButton;
    private String Adminid;
    @Override
    public void initialize(URL url, ResourceBundle rb) {

    }
    public void setAdminId(String id) {
        this.Adminid = id;
    }

    @FXML
    private void handleManageDoctors(ActionEvent event) {
        try {
            // Load the Manage Patients FXML file
            AnchorPane managePatientsPane = FXMLLoader.load(getClass().getResource("/smarthospitalmanagmentsystem/views/Mangedoc.fxml"));

            // Get the current stage from the event source
            stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            // Set the new scene to the stage
            stage.getScene().setRoot(managePatientsPane);
        } catch (IOException e) {
            e.printStackTrace();  // Handle exceptions appropriately
            // Optionally: Display an error dialog to the user
        }
    }

    @FXML
    private void handleManagePatients(ActionEvent event) {

        try {
            // Load the Manage Patients FXML file
            AnchorPane managePatientsPane = FXMLLoader.load(getClass().getResource("/smarthospitalmanagmentsystem/views/Manage_Patient.fxml"));

            // Get the current stage from the event source
            stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            // Set the new scene to the stage
            stage.getScene().setRoot(managePatientsPane);
        } catch (IOException e) {
            e.printStackTrace();  // Handle exceptions appropriately
            // Optionally: Display an error dialog to the user
        }

    }

    @FXML
    private void handleGenerateReports(ActionEvent event) {
        try {
            // Load the Manage Patients FXML file
            AnchorPane managePatientsPane = FXMLLoader.load(getClass().getResource("/smarthospitalmanagmentsystem/views/HospitalReports.fxml"));

            // Get the current stage from the event source
            stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            // Set the new scene to the stage
            stage.getScene().setRoot(managePatientsPane);
        } catch (IOException e) {
            e.printStackTrace();  // Handle exceptions appropriately
            // Optionally: Display an error dialog to the user
        }
    }

    @FXML
    private void handleBillingSystem(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/smarthospitalmanagmentsystem/views/BillingSystem.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }

    @FXML
    private void handleSOS(ActionEvent event) {
        try {

            AnchorPane managePatientsPane = FXMLLoader.load(getClass().getResource("/smarthospitalmanagmentsystem/views/Emergency_Report.fxml"));

            stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

            stage.getScene().setRoot(managePatientsPane);
        } catch (IOException e) {
            e.printStackTrace();  // Handle exceptions appropriately
            // Optionally: Display an error dialog to the user
        }

    }

    @FXML
    private void handleBack(ActionEvent event) throws IOException {
        Node source = (Node) event.getSource();
        stage = (Stage) source.getScene().getWindow();
        if (source == backButton) {
            root = FXMLLoader.load(getClass().getResource("/smarthospitalmanagmentsystem/views/log_in_page.fxml"));
        }

        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    

}
