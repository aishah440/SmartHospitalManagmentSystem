package smarthospitalmanagmentsystem.models;

import java.time.LocalDate;

public class Appointment {

    private Patient patient;
    private Doctor doctor;
    private LocalDate date;
    private String time;
    private double price; // Added price field
    private String title;

    public Appointment(Patient patient, Doctor doctor, LocalDate date, String time, double price, String title) {
        this.patient = patient;
        this.doctor = doctor;
        this.date = date;
        this.time = time;
        this.price = price;
        this.title = title;
    }

    public Appointment(Patient patient, LocalDate date, String time, double price, String title) {
        this.patient = patient;
        this.date = date;
        this.time = time;
        this.price = price;
        this.title = title;
    }
    
    
    
    public Appointment(Patient patient, Doctor doctor, LocalDate date, String time, double price) {
        this.patient = patient;
        this.doctor = doctor;
        this.date = date;
        this.time = time;
        this.price = price; // Set price in constructor
    }

    public Appointment(Patient patient, LocalDate date, String time, double price) {
        this.patient = patient;
        this.date = date;
        this.time = time;
        this.price = price;
    }

    public Appointment(Doctor doctor, LocalDate date, String time, double price) {
        this.doctor = doctor;
        this.date = date;
        this.time = time;
        this.price = price;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
    
    

    public Patient getPatient() {
        return patient;
    }

    public Doctor getDoctor() {
        return doctor;
    }

    public LocalDate getDate() {
        return date;
    }

    public String getTime() {
        return time;
    }

    public double getPrice() {
        return price;
    } // Getter for price

    // Setters
    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    public void setDoctor(Doctor doctor) {
        this.doctor = doctor;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public void setPrice(double price) {
        this.price = price;
    } // Setter for price

    @Override
    public String toString() {
        return "Appointment{"
                + "patient=" + patient.getName()
                + ", doctor=" + doctor.getName()
                + ", date=" + date
                + ", time='" + time + '\''
                + ", price=" + price
                + '}';
    }
}
