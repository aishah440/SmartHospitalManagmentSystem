package smarthospitalmanagmentsystem.controllers;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import smarthospitalmanagmentsystem.DB.DatabaseConnection;

public class BookingAppointmentController implements Initializable {

    private Stage stage;
    private Scene scene;
    private Parent root;

    @FXML
    private TextField patientIdField;
    @FXML
    private ComboBox<String> doctorComboBox;
    @FXML
    private DatePicker datePicker;
    @FXML
    private TextField timeField;
    @FXML
    private Button bookButton;
    @FXML
    private Button cancelButton;
    @FXML
    private TextField priceField;
    @FXML
    private TextField titleField;

    private String patientId;
    private Map<String, String> doctorNameToId = new HashMap<>();

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        loadDoctors();

        if (patientId != null && !patientId.isEmpty()) {
            patientIdField.setText(patientId);
            patientIdField.setDisable(true);
        }
    }

    public void setPatientId(String id) {
        this.patientId = id;
        if (patientIdField != null) {
            patientIdField.setText(id);
            patientIdField.setDisable(true);
        }
    }

    private void loadDoctors() {
        String query = "SELECT id, name FROM doctors";

        try ( Connection conn = DatabaseConnection.getInstance().getConnection();  Statement stmt = conn.createStatement();  ResultSet rs = stmt.executeQuery(query)) {

            doctorComboBox.getItems().clear();
            doctorNameToId.clear();

            while (rs.next()) {
                String id = rs.getString("id");
                String name = rs.getString("name");
                doctorNameToId.put(name, id);
                doctorComboBox.getItems().add(name);
            }

        } catch (SQLException e) {
            showAlert("Database Error", "Could not load doctors: " + e.getMessage());
        }
    }

    @FXML
    private void handleBook(ActionEvent event) {
        String doctorName = doctorComboBox.getValue();
        String doctorId = doctorNameToId.get(doctorName);
        LocalDate date = datePicker.getValue();
        String time = timeField != null && timeField.getText() != null ? timeField.getText().trim() : "";
        String priceText = priceField != null && priceField.getText() != null ? priceField.getText().trim() : "";
        String title = titleField != null && titleField.getText() != null ? titleField.getText().trim() : "";

        if ((patientId == null || patientId.isEmpty()) && patientIdField != null && patientIdField.getText() != null) {
            patientId = patientIdField.getText().trim();
        }

        if (patientId == null || patientId.isEmpty() || doctorId == null || date == null || time.isEmpty() || priceText.isEmpty() || title.isEmpty()) {
            showAlert("Validation Error", "All fields must be filled.");
            return;
        }

        double price;
        try {
            price = Double.parseDouble(priceText);
        } catch (NumberFormatException e) {
            showAlert("Input Error", "Price must be a valid number.");
            return;
        }

        String insertQuery = "INSERT INTO appointments (patient_id, doctor_id, date, time, price, title) VALUES (?, ?, ?, ?, ?, ?)";

        try ( Connection conn = DatabaseConnection.getInstance().getConnection();  PreparedStatement pstmt = conn.prepareStatement(insertQuery)) {

            pstmt.setString(1, patientId);
            pstmt.setString(2, doctorId);
            pstmt.setDate(3, Date.valueOf(date));
            pstmt.setString(4, time);
            pstmt.setDouble(5, price);
            pstmt.setString(6, title);

            int rows = pstmt.executeUpdate();
            if (rows > 0) {
                showAlert("Success", "Appointment booked successfully.");
                insertBillingRecord(patientId, "Appointment", price, date);
                clearFields();
            } else {
                showAlert("Error", "Failed to book appointment.");
            }

        } catch (SQLException e) {
            showAlert("Database Error", e.getMessage());
        }
    }

    private void clearFields() {
        doctorComboBox.setValue(null);
        datePicker.setValue(null);
        timeField.clear();
        priceField.clear();
        titleField.clear();
    }

    @FXML
    private void handleCancel(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/smarthospitalmanagmentsystem/views/Patient page.fxml"));
        Parent root = loader.load();

        PatientPageController controller = loader.getController();
        controller.setPatientId(patientId);

        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }

    private void insertBillingRecord(String patientId, String serviceType, double amount, LocalDate billingDate) {
        String billingQuery = "INSERT INTO billing (patient_id, service_type, amount, billing_date) VALUES (?, ?, ?, ?)";

        try ( Connection conn = DatabaseConnection.getInstance().getConnection();  PreparedStatement pstmt = conn.prepareStatement(billingQuery)) {
            pstmt.setString(1, patientId);
            pstmt.setString(2, serviceType);
            pstmt.setDouble(3, amount);
            pstmt.setDate(4, Date.valueOf(billingDate));
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
