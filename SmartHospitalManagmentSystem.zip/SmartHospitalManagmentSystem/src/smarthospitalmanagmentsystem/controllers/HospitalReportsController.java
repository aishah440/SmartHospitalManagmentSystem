package smarthospitalmanagmentsystem.controllers;

import java.io.IOException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import smarthospitalmanagmentsystem.DB.DatabaseConnection;
import smarthospitalmanagmentsystem.models.Report;

import java.sql.*;
import java.time.LocalDate;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class HospitalReportsController {

    private Stage stage;
    private Scene scene;
    private Parent root;

    @FXML
    private ComboBox<String> reportTypeComboBox;
    @FXML
    private DatePicker reportDatePicker;
    @FXML
    private TableView<Report> reportTable;
    @FXML
    private TableColumn<Report, String> typeColumn;
    @FXML
    private TableColumn<Report, String> messageColumn; // This represents the message/description
    @FXML
    private TableColumn<Report, Date> dateColumn;
    @FXML
    private Button cancelBtn;
    private ObservableList<Report> reportList = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        reportTypeComboBox.getItems().addAll("All", "Emergency", "Consultation", "Patient");
        reportTypeComboBox.setValue("All");

        typeColumn.setCellValueFactory(new PropertyValueFactory<>("reportType"));
        messageColumn.setCellValueFactory(new PropertyValueFactory<>("message")); // Use message from the Report class
        dateColumn.setCellValueFactory(new PropertyValueFactory<>("reportDate"));

        reportTable.setItems(reportList);

        // Show all on load
        fetchAllReports();
    }

    @FXML
    private void handleGenerateReport() {
        String selectedType = reportTypeComboBox.getValue();
        LocalDate selectedDate = reportDatePicker.getValue();

        reportList.clear();
        if (selectedType.equals("All")) {
            if (selectedDate == null) {
                fetchAllReports();
            } else {
                fetchAllReports(selectedDate);
            }
        } else {
            fetchReportsByType(selectedType, selectedDate);
        }
    }

    private void fetchAllReports() {
        fetchFromTable("emergency_alerts", "Emergency");
        fetchFromTable("consultations", "Consultation");
        fetchFromTable("patients", "Patient");
    }

    private void fetchAllReports(LocalDate date) {
        if (date == null) {
            return;
        }
        fetchFromTable("emergency_alerts", "Emergency", date);
        fetchFromTable("consultations", "Consultation", date);
        fetchFromTable("patients", "Patient", date);
    }

    private void fetchReportsByType(String type, LocalDate date) {
        String table = getTableName(type);
        if (table != null) {
            if (date == null) {
                fetchFromTable(table, type);
            } else {
                fetchFromTable(table, type, date);
            }
        }
    }

    private void fetchFromTable(String table, String type) {
        String query = "SELECT * FROM " + table;
        try ( Connection conn = DatabaseConnection.getInstance().getConnection();  PreparedStatement stmt = conn.prepareStatement(query);  ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                if ("consultations".equals(table)) {
                    reportList.add(new Report(
                            rs.getInt("id"),
                            type,
                            rs.getString("description"), // Assuming description is used instead of message
                            rs.getDate("consultation_date") // Use the correct date field
                    ));
                } else if ("patients".equals(table)) {
                    reportList.add(new Report(
                            rs.getInt("patient_id"), // Assuming patient_id as ID
                            type,
                            rs.getString("patient_name"), // Use patient_name
                            null // No date field for patients
                    ));
                } else if ("emergency_alerts".equals(table)) {
                    reportList.add(new Report(
                            rs.getInt("id"),
                            type,
                            rs.getString("message"), // Use message for emergency alerts
                            rs.getDate("reportDate") // Use reportDate
                    ));
                }
            }

        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Database Error", e.getMessage());
        }
    }

    private void fetchFromTable(String table, String type, LocalDate date) {
        if (date == null) {
            return;
        }
        String query = "SELECT * FROM " + table + " WHERE reportDate = ?";
        try ( Connection conn = DatabaseConnection.getInstance().getConnection();  PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setDate(1, Date.valueOf(date));
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                if ("consultations".equals(table)) {
                    reportList.add(new Report(
                            rs.getInt("id"),
                            type,
                            rs.getString("description"),
                            rs.getDate("consultation_date")
                    ));
                } else if ("patients".equals(table)) {
                    reportList.add(new Report(
                            rs.getInt("patient_id"), // Assuming patient_id as ID
                            type,
                            rs.getString("patient_name"),
                            null // No date field for patients
                    ));
                } else if ("emergency_alerts".equals(table)) {
                    reportList.add(new Report(
                            rs.getInt("id"),
                            type,
                            rs.getString("message"),
                            rs.getDate("reportDate")
                    ));
                }
            }

        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Database Error", e.getMessage());
        }
    }

    private String getTableName(String type) {
        return switch (type) {
            case "Emergency" ->
                "emergency_alerts";
            case "Consultation" ->
                "consultations";
            case "Patient" ->
                "patients";
            default ->
                null;
        };
    }

    @FXML
    private void handelCancelBtn(ActionEvent event) throws IOException {
        Node source = (Node) event.getSource();
        stage = (Stage) source.getScene().getWindow();
        if (source == cancelBtn) {
            root = FXMLLoader.load(getClass().getResource("/smarthospitalmanagmentsystem/views/Admin_page.fxml"));
            scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        }
    }

    private void showAlert(Alert.AlertType type, String title, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
