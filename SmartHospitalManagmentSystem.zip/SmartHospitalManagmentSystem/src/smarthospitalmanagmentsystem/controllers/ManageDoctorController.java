package smarthospitalmanagmentsystem.controllers;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import javafx.scene.Node;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import smarthospitalmanagmentsystem.DB.DatabaseConnection;
import smarthospitalmanagmentsystem.models.Doctor;

public class ManageDoctorController {

    @FXML
    private TableView<Doctor> doctorTable;

    @FXML
    private TableColumn<Doctor, String> doctorIDColumn, doctorNameColumn, specializationColumn;

    @FXML
    private TableColumn<Doctor, Void> actionsColumn;

    @FXML
    private TextField searchField;

    @FXML
    private Button backButton;

    private ObservableList<Doctor> doctorList = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        setupTable();
        loadDoctorsFromDatabase();
    }

    private void setupTable() {
        doctorIDColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        doctorNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        specializationColumn.setCellValueFactory(new PropertyValueFactory<>("specialization"));

        actionsColumn.setCellFactory(param -> new TableCell<>() {
            private final Button editButton = new Button("Edit");
            private final Button deleteButton = new Button("Delete");

            {
                editButton.setOnAction(event -> handleEditDoctor(getTableView().getItems().get(getIndex())));
                deleteButton.setOnAction(event -> handleDeleteDoctor(getTableView().getItems().get(getIndex())));
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    setGraphic(new HBox(10, editButton, deleteButton));
                }
            }
        });

        doctorTable.setItems(doctorList);
    }

    private void loadDoctorsFromDatabase() {
        doctorList.clear();
        String query = "SELECT * FROM doctors";
        try ( Connection conn = DatabaseConnection.getInstance().getConnection();  PreparedStatement stmt = conn.prepareStatement(query);  ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                doctorList.add(new Doctor(
                        rs.getString("id"),
                        rs.getString("name"),
                        rs.getString("specialization")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleSearchDoctor() {
        String searchId = searchField.getText().trim();
        if (searchId.isEmpty()) {
            loadDoctorsFromDatabase();
            return;
        }

        doctorList.clear();
        String query = "SELECT * FROM doctors WHERE id = ?";
        try ( Connection conn = DatabaseConnection.getInstance().getConnection();  PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, searchId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                doctorList.add(new Doctor(
                        rs.getString("id"),
                        rs.getString("name"),
                        rs.getString("specialization")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleAddDoctor() throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/smarthospitalmanagmentsystem/views/AddDoctor.fxml"));
        Parent root = loader.load();
        Stage stage = new Stage();
        stage.setTitle("Add Doctor");
        stage.setScene(new Scene(root));
        stage.showAndWait(); // wait for closing before refreshing
        loadDoctorsFromDatabase();
    }

    private void handleEditDoctor(Doctor doctor) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/smarthospitalmanagmentsystem/views/EditDoctor.fxml"));
            Parent root = loader.load();

            EditDoctorController controller = loader.getController();
            if (controller == null) {
                System.out.println("⚠️ Controller is null - check fx:controller in EditDoctor.fxml!");
            } else {
                controller.setDoctorData(doctor);
            }

            Stage stage = new Stage();
            stage.setTitle("Edit Doctor");
            stage.setScene(new Scene(root));
            stage.showAndWait();
            loadDoctorsFromDatabase();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void handleDeleteDoctor(Doctor doctor) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Are you sure you want to delete this doctor?",
                ButtonType.YES, ButtonType.NO);
        alert.showAndWait().ifPresent(response -> {
            if (response == ButtonType.YES) {
                try ( Connection conn = DatabaseConnection.getInstance().getConnection();  PreparedStatement stmt = conn.prepareStatement("DELETE FROM doctors WHERE id = ?")) {
                    stmt.setString(1, doctor.getId());
                    stmt.executeUpdate();
                    doctorList.remove(doctor);
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    @FXML
    private void handleBack(ActionEvent event) throws IOException {
        Node source = (Node) event.getSource();
        Stage stage = (Stage) source.getScene().getWindow();
        Parent root = FXMLLoader.load(getClass().getResource("/smarthospitalmanagmentsystem/views/Admin_Page.fxml"));
        stage.setScene(new Scene(root));
        stage.show();
    }

    @FXML
    private void handleShowAllDoctors() {
        loadDoctorsFromDatabase();
    }

    
}
