// Updated Manage_PatientController.java
package smarthospitalmanagmentsystem.controllers;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.beans.property.SimpleStringProperty;
import javafx.event.ActionEvent;
import javafx.scene.Node;
import javafx.scene.layout.HBox;
import smarthospitalmanagmentsystem.DB.DatabaseConnection;
import smarthospitalmanagmentsystem.models.Patient;

public class Manage_PatientController {

    private Stage stage;
    private Scene scene;
    private Parent root;

    @FXML
    private TableView<Patient> patientTable;

    @FXML
    private TableColumn<Patient, String> patientIDColumn, patientNameColumn, medicalConditionColumn, medicationsColumn;

    @FXML
    private TableColumn<Patient, Void> actionsColumn;

    @FXML
    private TextField searchField;

    @FXML
    private Button backButton;

    private ObservableList<Patient> patientList = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        setupTable();
        loadPatientsFromDatabase();
    }

    private void setupTable() {
        patientIDColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getId()));
        patientNameColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getName()));
        medicalConditionColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getMedicalCondition()));
        medicationsColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getCurrentMedications()));

        actionsColumn.setCellFactory(param -> new TableCell<>() {
            private final Button editButton = new Button("Edit");
            private final Button deleteButton = new Button("Delete");

            {
                editButton.setOnAction(event -> handleEditPatient(getTableView().getItems().get(getIndex())));
                deleteButton.setOnAction(event -> handleDeletePatient(getTableView().getItems().get(getIndex())));
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    setGraphic(new HBox(10, editButton, deleteButton));
                }
            }
        });

        patientTable.setItems(patientList);
    }

    private void loadPatientsFromDatabase() {
        patientList.clear();
        String query = "SELECT * FROM patients";
        try ( Connection conn = DatabaseConnection.getInstance().getConnection();  PreparedStatement stmt = conn.prepareStatement(query);  ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                patientList.add(new Patient(
                        rs.getString("patient_id"),
                        rs.getString("patient_name"),
                        rs.getString("medical_condition"),
                        rs.getString("current_medications")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleSearchPatient() {
        String searchId = searchField.getText().trim();
        if (searchId.isEmpty()) {
            loadPatientsFromDatabase();
            return;
        }

        patientList.clear();
        String query = "SELECT * FROM patients WHERE patient_id = ?";
        try ( Connection conn = DatabaseConnection.getInstance().getConnection();  PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, searchId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                patientList.add(new Patient(
                        rs.getString("patient_id"),
                        rs.getString("patient_name"),
                        rs.getString("medical_condition"),
                        rs.getString("current_medications")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleAddPatient() throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/smarthospitalmanagmentsystem/views/Add_Patient.fxml"));
        Parent root = loader.load();
        Stage stage = new Stage();
        stage.setTitle("Add Patient");
        stage.setScene(new Scene(root));
        stage.showAndWait();
        loadPatientsFromDatabase();
    }

    private void handleEditPatient(Patient patient) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/smarthospitalmanagmentsystem/views/Edit_Patient.fxml"));
            Parent root = loader.load();
            Edit_PatientController controller = loader.getController();
            controller.setPatientData(patient);
            Stage stage = new Stage();
            stage.setTitle("Edit Patient");
            stage.setScene(new Scene(root));
            stage.showAndWait();
            loadPatientsFromDatabase();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void handleDeletePatient(Patient patient) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Are you sure you want to delete this patient?",
                ButtonType.YES, ButtonType.NO);
        alert.showAndWait().ifPresent(response -> {
            if (response == ButtonType.YES) {
                try ( Connection conn = DatabaseConnection.getInstance().getConnection()) {
                    try ( PreparedStatement deletePrescriptionsStmt = conn.prepareStatement("DELETE FROM prescriptions WHERE patient_id = ?")) {
                        deletePrescriptionsStmt.setString(1, patient.getId());
                        deletePrescriptionsStmt.executeUpdate();
                    }

                    try ( PreparedStatement deletePatientStmt = conn.prepareStatement("DELETE FROM patients WHERE patient_id = ?")) {
                        deletePatientStmt.setString(1, patient.getId());
                        deletePatientStmt.executeUpdate();
                        patientList.remove(patient);
                    }

                    showAlert("Success", "Patient deleted successfully.");
                } catch (SQLException e) {
                    e.printStackTrace();
                    showAlert("Database Error", e.getMessage());
                }
            }
        });
    }

    @FXML
    private void handleBack(ActionEvent event) throws IOException {
        Node source = (Node) event.getSource();
        stage = (Stage) source.getScene().getWindow();
        if (source == backButton) {
            root = FXMLLoader.load(getClass().getResource("/smarthospitalmanagmentsystem/views/Admin_page.fxml"));
        }

        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void handleShowAllPatients() {
        loadPatientsFromDatabase();
    }

    @FXML
    private void handleCancel(ActionEvent event) {
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close();
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
