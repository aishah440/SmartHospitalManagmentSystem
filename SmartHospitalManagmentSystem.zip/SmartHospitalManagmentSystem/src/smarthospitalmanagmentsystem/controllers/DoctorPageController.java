package smarthospitalmanagmentsystem.controllers;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class DoctorPageController implements Initializable {

    private Stage stage;
    private Scene scene;
    private Parent root;

    private String doctorId; // Field to store logged-in doctor ID

    @FXML
    private Button viewRecordsButton;
    @FXML
    private Button scheduleConsultationButton;
    @FXML
    private Button prescribeMedicationButton;
    @FXML
    private Button backButton;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Any initialization logic goes here
    }

    public void setDoctorId(String id) {
        this.doctorId = id;
    }

    @FXML
    private void goToPatientRecords(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/smarthospitalmanagmentsystem/views/PatientRecords.fxml"));
            AnchorPane pane = loader.load();

            PatientRecordsController controller = loader.getController();
            controller.setDoctorId(doctorId); // ✅ Pass doctor ID

            stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.getScene().setRoot(pane);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //scheduleconsultation
    @FXML
    private void goToScheduleConsultation(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/smarthospitalmanagmentsystem/views/scheduleconsultation.fxml"));
Parent root = loader.load();
ScheduleConsultationController controller = loader.getController();  // ✅ CORRECT cast
        controller.setDoctorId(doctorId);  // pass logged-in doctor ID

        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }

    @FXML
    private void goToPrescribeMedication(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/smarthospitalmanagmentsystem/views/PrescriptionmanagementScree.fxml"));
        Parent root = loader.load();

        // Get controller and set doctor ID
        PrescriptionmanagementScreeController controller = loader.getController();
        controller.setDoctorId(doctorId);  // doctorId should be already available in this controller

        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }

    @FXML
    private void handleViewAppointments(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/smarthospitalmanagmentsystem/views/Doctor_View_Appointments.fxml"));
            AnchorPane pane = loader.load();

            DoctorViewAppointmentsController controller = loader.getController();
            controller.setDoctorId(doctorId);

            stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.getScene().setRoot(pane);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleBack(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("/smarthospitalmanagmentsystem/views/Log_in_page.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
}
