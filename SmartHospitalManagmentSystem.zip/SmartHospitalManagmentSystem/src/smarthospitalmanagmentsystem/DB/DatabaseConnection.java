
package smarthospitalmanagmentsystem.DB;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {
    private static final String URL = "jdbc:mysql://localhost:3306/hospital";
    private static final String USER = "root";
    private static final String PASSWORD = "Aeshahal4@";
    
    private static DatabaseConnection instance;
    private Connection connection;

    // Private constructor to ensure singleton property
    private DatabaseConnection() {
        try {
            connection = DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (SQLException e) {
            throw new RuntimeException("Failed to connect to database!", e);
        }
    }

    // Singleton instance retrieval
    public static DatabaseConnection getInstance() {
        if (instance == null || instance.connection == null) {
            instance = new DatabaseConnection();
        }
        return instance;
    }

    // This method returns the current database connection
    public Connection getConnection() {
        try {
            if (connection == null || connection.isClosed()) {
                connection = DriverManager.getConnection(URL, USER, PASSWORD);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return connection;
    }
    }
