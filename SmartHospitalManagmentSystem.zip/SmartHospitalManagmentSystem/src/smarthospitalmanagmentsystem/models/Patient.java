
package smarthospitalmanagmentsystem.models;

import java.util.ArrayList;
import java.util.List;



public class Patient extends User {
    
    private String medicalCondition;
    private String currentMedications;
    private List<Prescription> prescriptions;

    public Patient(String id, String name) {
        super(id, name);
        
    }

    public Patient(String id, String name, String medicalCondition, String currentMedications) {
        super(id, name);
        this.medicalCondition = medicalCondition;
        this.currentMedications = currentMedications;
        this.prescriptions = new ArrayList<>();
    }
    
    

    

    

    public String getMedicalCondition() {
        return medicalCondition;
    }

    public void setMedicalCondition(String medicalCondition) {
        this.medicalCondition = medicalCondition;
    }

    public String getCurrentMedications() {
        return currentMedications;
    }

    public void setCurrentMedications(String currentMedications) {
        this.currentMedications = currentMedications;
    }
    public void addPrescription(Prescription prescription) {
        if (!prescriptions.contains(prescription)) {
            prescriptions.add(prescription);
        }
    }

    public List<Prescription> getPrescriptions() {
        return prescriptions;
    }

    
    
    // Override toString() method
    @Override
    public String toString() {
        return "Patient{" +
                "id='" + super.getId() + '\'' +
                ", name='" + super.getName() + '\'' +
                 '\'' +
                '}';
    }
}

