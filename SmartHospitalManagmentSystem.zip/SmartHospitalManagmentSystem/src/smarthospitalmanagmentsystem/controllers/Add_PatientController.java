package smarthospitalmanagmentsystem.controllers;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import smarthospitalmanagmentsystem.DB.DatabaseConnection;

public class Add_PatientController {

    private Stage stage;
    private Scene scene;
    private Parent root;

    @FXML
    private TextField patientIdField;

    @FXML
    private TextField patientNameField;

    @FXML
    private TextField medicalConditionField;

    @FXML
    private TextArea currentMedicationsField;

    @FXML
    private Button addButton;

    @FXML
    private Button backButton;

    @FXML
    private void handleAddPatient() {
        String patientId = patientIdField.getText().trim();
        String patientName = patientNameField.getText().trim();
        String medicalCondition = medicalConditionField.getText().trim();
        String currentMedications = currentMedicationsField.getText().trim();

        if (patientId.isEmpty() || patientName.isEmpty() || medicalCondition.isEmpty() || currentMedications.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Validation Error", "All fields are required.");
            return;
        }

        if (!patientId.matches("\\d+")) {
            showAlert(Alert.AlertType.ERROR, "Validation Error", "Patient ID must be a number.");
            return;
        }

        if (!patientName.matches("[a-zA-Z\\s]+")) {
            showAlert(Alert.AlertType.ERROR, "Validation Error", "Patient name must contain only letters and spaces.");
            return;
        }

        String userPassword = hashPassword("patient" + patientId + patientName); // Unique default password

        String insertUser = "INSERT INTO users (id, name, password, userType) VALUES (?, ?, ?, 'Patient')";
        String insertPatient = "INSERT INTO patients (patient_id, patient_name, medical_condition, current_medications) VALUES (?, ?, ?, ?)";

        try ( Connection conn = DatabaseConnection.getInstance().getConnection()) {
            if (conn == null) {
                showAlert(Alert.AlertType.ERROR, "Database Error", "Database connection failed.");
                return;
            }

            conn.setAutoCommit(false); // Begin transaction

            try ( PreparedStatement userStmt = conn.prepareStatement(insertUser);  PreparedStatement patientStmt = conn.prepareStatement(insertPatient)) {

                // Insert into users
                userStmt.setString(1, patientId);
                userStmt.setString(2, patientName);
                userStmt.setString(3, userPassword);
                userStmt.executeUpdate();

                // Insert into patients
                patientStmt.setString(1, patientId);
                patientStmt.setString(2, patientName);
                patientStmt.setString(3, medicalCondition);
                patientStmt.setString(4, currentMedications);
                patientStmt.executeUpdate();

                conn.commit(); // Commit transaction
                showAlert(Alert.AlertType.INFORMATION, "Success", "Patient and user account added successfully!");
                clearFields();
            } catch (SQLException e) {
                conn.rollback(); // Rollback if failure
                showAlert(Alert.AlertType.ERROR, "Insert Error", "Could not add patient: " + e.getMessage());
            }
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Database Error", e.getMessage());
        }
    }

    private String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = md.digest(password.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : hashBytes) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            showAlert(Alert.AlertType.ERROR, "Error", "Password hashing error: " + e.getMessage());
            return password;
        }
    }

    @FXML
    private void handleBack(ActionEvent event) throws IOException {
        Node source = (Node) event.getSource();
        Stage stage = (Stage) source.getScene().getWindow();
        stage.close();
    }
    //Manage_Patient

    private void clearFields() {
        patientIdField.clear();
        patientNameField.clear();
        medicalConditionField.clear();
        currentMedicationsField.clear();
    }

    private void showAlert(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
