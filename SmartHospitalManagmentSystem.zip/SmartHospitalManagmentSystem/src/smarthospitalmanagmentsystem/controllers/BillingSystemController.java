package smarthospitalmanagmentsystem.controllers;

import java.io.IOException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import smarthospitalmanagmentsystem.DB.DatabaseConnection;
import smarthospitalmanagmentsystem.models.Billing;
import smarthospitalmanagmentsystem.models.Patient;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.sql.*;
import java.time.LocalDate;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.layout.AnchorPane;

public class BillingSystemController {

    @FXML private TableView<Billing> billingTable;
    @FXML private TableColumn<Billing, String> colPatientName;
    @FXML private TableColumn<Billing, String> colService;
    @FXML private TableColumn<Billing, Double> colAmount;
    @FXML private TableColumn<Billing, String> colDate;

    @FXML private TextField patientIdField;
    @FXML private TextField totalField;
    @FXML private AnchorPane billingRoot;

    private ObservableList<Billing> billings = FXCollections.observableArrayList();

    @FXML
    private void initialize() {
        colPatientName.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getPatient().getName()));
        colService.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getServiceType()));
        colAmount.setCellValueFactory(data -> new SimpleDoubleProperty(data.getValue().getAmount()).asObject());
        colDate.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getBillingDate().toString()));
    }

    @FXML
    private void handleGenerateBill() {
        String patientId = patientIdField.getText().trim();
        if (patientId.isEmpty()) {
            showAlert("Please enter a Patient ID.");
            return;
        }

        billings.clear();
        double total = 0.0;

        String query = """
            SELECT b.billing_id, b.patient_id, p.patient_name, b.service_type, b.amount, b.billing_date
            FROM billing b
            JOIN patients p ON b.patient_id = p.patient_id
            WHERE b.patient_id = ?
        """;

        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, patientId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Patient patient = new Patient(rs.getString("patient_id"), rs.getString("patient_name"));
                Billing billing = new Billing(
                        rs.getString("billing_id"),
                        patient,
                        rs.getString("service_type"),
                        rs.getDouble("amount"),
                        rs.getDate("billing_date").toLocalDate()
                );
                total += billing.getAmount();
                billings.add(billing);
            }

            billingTable.setItems(billings);
            totalField.setText(String.format("%.2f", total));

        } catch (SQLException e) {
            showAlert("Error loading billing data: " + e.getMessage());
        }
    }
    
    

    @FXML
    private void handleBack(ActionEvent event) throws IOException {
        Node source = (Node) event.getSource();
        Stage stage = (Stage) source.getScene().getWindow();
        Parent root = FXMLLoader.load(getClass().getResource("/smarthospitalmanagmentsystem/views/Admin_page.fxml"));
        stage.setScene(new Scene(root));
        stage.show();
    }

    private void showAlert(String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setContentText(msg);
        alert.showAndWait();
    }
}
