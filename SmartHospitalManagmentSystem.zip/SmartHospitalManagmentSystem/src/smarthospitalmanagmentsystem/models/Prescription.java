
package smarthospitalmanagmentsystem.models;





public class Prescription {
    private Patient patient;  // Composition: Prescription contains Patient
    private String prescription;
    private String createdAt;

    public Prescription(Patient patient, String prescription, String createdAt) {
        this.patient = patient;
        this.prescription = prescription;
        this.createdAt = createdAt;
    }

    public Prescription(String prescription) {
        this.prescription = prescription;
    }
    

    public Patient getPatient() {
        return patient;
    }

    public String getPrescription() {
        return prescription;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    // Setters
    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    public void setPrescription(String prescription) {
        this.prescription = prescription;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    @Override
    public String toString() {
        return prescription ;
    }
    
    
    
    
}
