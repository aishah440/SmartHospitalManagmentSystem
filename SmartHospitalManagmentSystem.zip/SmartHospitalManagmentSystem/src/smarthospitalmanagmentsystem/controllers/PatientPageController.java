package smarthospitalmanagmentsystem.controllers;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class PatientPageController implements Initializable {

    private Stage stage;
    private Scene scene;
    private Parent root;
    private String patientId;

    @FXML
    private Button bookAppointmentButton;
    @FXML
    private Button viewMedicalHistoryButton;
    @FXML
    private Button receiveRemindersButton;
    @FXML
    private Button backButton;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
    }

    public void setPatientId(String id) {
        this.patientId = id;
    }

    @FXML
    private void handleBookAppointment(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/smarthospitalmanagmentsystem/views/Booking Appointment.fxml"));
            root = loader.load();

            BookingAppointmentController controller = loader.getController();
            controller.setPatientId(patientId);

            stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleViewAppointment(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/smarthospitalmanagmentsystem/views/View Appointments.fxml"));
            root = loader.load();

            ViewAppointmentsController controller = loader.getController();
            controller.setPatientId(patientId);

            stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleViewMedicalHistory(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/smarthospitalmanagmentsystem/views/View Medical History.fxml"));
            root = loader.load();

            ViewMedicalHistoryController controller = loader.getController();
            controller.setPatientId(patientId);

            stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleReceiveReminders(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/smarthospitalmanagmentsystem/views/Create Reminder_1.fxml"));
            root = loader.load();

            CreateReminderController controller = loader.getController();
            controller.setPatientId(patientId); // ✅ Pass logged-in patient ID

            stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleBack(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("/smarthospitalmanagmentsystem/views/Log_in_page.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
}
