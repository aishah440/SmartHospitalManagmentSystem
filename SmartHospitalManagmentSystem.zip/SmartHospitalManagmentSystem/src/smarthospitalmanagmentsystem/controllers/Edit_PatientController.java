// Updated Edit_PatientController.java
package smarthospitalmanagmentsystem.controllers;

import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.stage.Stage;
import smarthospitalmanagmentsystem.DB.DatabaseConnection;
import smarthospitalmanagmentsystem.models.Patient;

public class Edit_PatientController implements Initializable {

    @FXML
    private TextField patientIdField;

    @FXML
    private TextField patientNameField;

    @FXML
    private TextField medicalConditionField;

    @FXML
    private TextArea medicationsField;

    @FXML
    private Button cancelBtn;
    @FXML
private Button saveChangesBtn;


    private Patient currentPatient;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Nothing to initialize initially
    }

    public void setPatientData(Patient patient) {
        this.currentPatient = patient;
        patientIdField.setText(patient.getId());
        patientNameField.setText(patient.getName());
        medicalConditionField.setText(patient.getMedicalCondition());
        medicationsField.setText(patient.getCurrentMedications());
    }

    @FXML
    private void handleUpdatePatient(ActionEvent event) {
        String id = patientIdField.getText().trim();
        String name = patientNameField.getText().trim();
        String medicalCondition = medicalConditionField.getText().trim();
        String medications = medicationsField.getText().trim();

        if (id.isEmpty() || name.isEmpty() || medicalCondition.isEmpty() || medications.isEmpty()) {
            showAlert("Validation Error", "All fields must be filled.");
            return;
        }

        String updateQuery = "UPDATE patients SET patient_name = ?, medical_condition = ?, current_medications = ? WHERE patient_id = ?";

        try ( Connection conn = DatabaseConnection.getInstance().getConnection();  PreparedStatement stmt = conn.prepareStatement(updateQuery)) {
            stmt.setString(1, name);
            stmt.setString(2, medicalCondition);
            stmt.setString(3, medications);
            stmt.setString(4, id);

            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                showAlert("Success", "Patient updated successfully.");
                closeWindow();
            } else {
                showAlert("Update Failed", "No matching patient found.");
            }

        } catch (SQLException e) {
            showAlert("Database Error", "Failed to update patient: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    private void handleCancelBtn(ActionEvent event) {
        closeWindow();
    }

    private void closeWindow() {
        Stage stage = (Stage) cancelBtn.getScene().getWindow();
        stage.close();
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
