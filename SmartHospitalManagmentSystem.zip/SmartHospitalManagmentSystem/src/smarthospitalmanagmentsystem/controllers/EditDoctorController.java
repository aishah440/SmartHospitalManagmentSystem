package smarthospitalmanagmentsystem.controllers;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import smarthospitalmanagmentsystem.DB.DatabaseConnection;
import smarthospitalmanagmentsystem.models.Doctor;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class EditDoctorController {

    @FXML
    private TextField doctorIdField;

    @FXML
    private TextField doctorNameField;

    @FXML
    private ComboBox<String> specializationComboBox;

    private Doctor currentDoctor;

    public void setDoctorData(Doctor doctor) {
        this.currentDoctor = doctor;
        doctorIdField.setText(doctor.getId());
        doctorNameField.setText(doctor.getName());
        specializationComboBox.setValue(doctor.getSpecialization());

        // Optional: Populate combo box with specialization options if not already done in FXML
        specializationComboBox.getItems().addAll("Cardiologist", "Neurologist", "Orthopedic", "Dermatologist", "Pediatrician");
    }

    @FXML
    private void handleSave() {
        String updatedId = doctorIdField.getText().trim();
        String updatedName = doctorNameField.getText().trim();
        String updatedSpecialization = specializationComboBox.getValue();

        if (updatedId.isEmpty() || updatedName.isEmpty() || updatedSpecialization == null) {
            showAlert(Alert.AlertType.ERROR, "Validation Error", "All fields must be filled.");
            return;
        }

        String query = "UPDATE doctors SET name = ?, specialization = ? WHERE id = ?";

        try ( Connection conn = DatabaseConnection.getInstance().getConnection();  PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, updatedName);
            stmt.setString(2, updatedSpecialization);
            stmt.setString(3, updatedId);

            int rowsUpdated = stmt.executeUpdate();
            if (rowsUpdated > 0) {
                showAlert(Alert.AlertType.INFORMATION, "Success", "Doctor updated successfully.");
                closeWindow();
            } else {
                showAlert(Alert.AlertType.ERROR, "Error", "Failed to update doctor.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Database Error", e.getMessage());
        }
    }

    @FXML
    private void handleCancel() {
        closeWindow();
    }

    private void closeWindow() {
        Stage stage = (Stage) doctorIdField.getScene().getWindow();
        stage.close();
    }

    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
