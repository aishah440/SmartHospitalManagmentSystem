package smarthospitalmanagmentsystem.controllers;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import smarthospitalmanagmentsystem.DB.DatabaseConnection;

public class Emergency_ReportController {

    private Stage stage;
    private Scene scene;
    private Parent root;

    @FXML
    private ComboBox<String> alertTypeComboBox;

    @FXML
    private TextArea alertMessageField;

    @FXML
    private Button cancelBtn;

    @FXML
    public void initialize() {
        alertTypeComboBox.getItems().addAll(
                "Emergency",
                "System Failure",
                "Medical Alert",
                "Security Alert",
                "Fire Alarm",
                "Maintenance Required"
        );
        alertTypeComboBox.setValue("Select Alert Type");
    }

    @FXML
    private void handleSend() {
        String alertType = alertTypeComboBox.getValue();
        String message = alertMessageField.getText().trim();

        if (alertType.equals("Select Alert Type") || message.isEmpty()) {
            showAlert("Error", "Please select an alert type and enter a message.", Alert.AlertType.ERROR);
            return;
        }

        // Save the alert to the database
        try ( Connection conn = smarthospitalmanagmentsystem.DB.DatabaseConnection.getInstance().getConnection()) {
            String sql = "INSERT INTO emergency_alerts (alert_type, message, reportDate) VALUES (?, ?, CURDATE())";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, alertType);
            stmt.setString(2, message);

            int rowsInserted = stmt.executeUpdate();
            if (rowsInserted > 0) {
                showAlert("Success", "Alert saved and sent successfully!", Alert.AlertType.INFORMATION);
                handleClear(); // Clear the form after successful insert
            } else {
                showAlert("Failure", "Failed to save the alert.", Alert.AlertType.ERROR);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Database Error", "Could not save the alert:\n" + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void handleClear() {
        alertMessageField.clear();
        alertTypeComboBox.setValue("Select Alert Type");
    }

    @FXML
    private void handelCancelBtn(ActionEvent event) throws IOException {
        Node source = (Node) event.getSource();
        stage = (Stage) source.getScene().getWindow();
        if (source == cancelBtn) {
            root = FXMLLoader.load(getClass().getResource("/smarthospitalmanagmentsystem/views/Admin_page.fxml"));
        }

        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    private void showAlert(String title, String message, Alert.AlertType type) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
