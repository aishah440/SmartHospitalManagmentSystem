package smarthospitalmanagmentsystem.models;

import java.time.LocalDate;

public class Reminder {
    private int id;
    private String title;
    private String description;
    private LocalDate reminderDate;
    private String patientId;

    public Reminder(int id, String title, String description, LocalDate reminderDate, String patientId) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.reminderDate = reminderDate;
        this.patientId = patientId;
    }

    // Getters and Setters
    public int getId() { return id; }
    public String getTitle() { return title; }
    public String getDescription() { return description; }
    public LocalDate getReminderDate() { return reminderDate; }
    public String getPatientId() { return patientId; }

    public void setId(int id) { this.id = id; }
    public void setTitle(String title) { this.title = title; }
    public void setDescription(String description) { this.description = description; }
    public void setReminderDate(LocalDate reminderDate) { this.reminderDate = reminderDate; }
    public void setPatientId(String patientId) { this.patientId = patientId; }
}
