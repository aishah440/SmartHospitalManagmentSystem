package smarthospitalmanagmentsystem.controllers;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.Node;

import smarthospitalmanagmentsystem.DB.DatabaseConnection;
import smarthospitalmanagmentsystem.models.Patient;
import smarthospitalmanagmentsystem.models.Prescription;

import java.io.IOException;
import java.sql.*;

public class UpdatePatienthistoryController {

    @FXML
    private TextField patientNameField;
    @FXML
    private TextField medicalConditionField;
    @FXML
    private TextField prescriptionField;
    @FXML
    private TextArea currentMedicationsArea;

    private Patient currentPatient;
    private PatientRecordsController patientRecordsController;
    private String doctorId;
    private Stage stage;
    private Scene scene;
    private Parent root;

    public void initializeWithPatient(Patient patient, PatientRecordsController controller, String doctorId) {
        this.currentPatient = patient;
        this.patientRecordsController = controller;
        this.doctorId = doctorId;

        patientNameField.setText(patient.getName());
        medicalConditionField.setText(patient.getMedicalCondition());
        currentMedicationsArea.setText(patient.getCurrentMedications());

        if (patient.getPrescriptions() != null && !patient.getPrescriptions().isEmpty()) {
            prescriptionField.setText(patient.getPrescriptions().get(patient.getPrescriptions().size() - 1).getPrescription());
        } else {
            prescriptionField.setText("");
        }
    }

    @FXML
    private void handleUpdate() {
        String condition = medicalConditionField.getText().trim();
        String medications = currentMedicationsArea.getText().trim();
        String prescriptionText = prescriptionField.getText().trim();

        if (condition.isEmpty() || medications.isEmpty() || prescriptionText.isEmpty()) {
            showAlert("Validation Error", "All fields must be filled.");
            return;
        }

        currentPatient.setMedicalCondition(condition);
        currentPatient.setCurrentMedications(medications);

        updatePatientInDatabase(currentPatient);
        savePrescriptionIfNew(currentPatient.getId(), prescriptionText);

        showAlert("Success", "Patient updated successfully.");
        patientRecordsController.loadAllPatients();
    }

    private void updatePatientInDatabase(Patient patient) {
        String sql = "UPDATE patients SET medical_condition = ?, current_medications = ? WHERE patient_id = ?";

        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, patient.getMedicalCondition());
            stmt.setString(2, patient.getCurrentMedications());
            stmt.setString(3, patient.getId());
            stmt.executeUpdate();

        } catch (SQLException e) {
            showAlert("Database Error", e.getMessage());
        }
    }

    private void savePrescriptionIfNew(String patientId, String prescriptionText) {
        String checkSql = "SELECT COUNT(*) FROM prescriptions WHERE patient_id = ? AND prescription = ?";
        String insertSql = "INSERT INTO prescriptions (patient_id, prescription, doctor_id, created_at) VALUES (?, ?, ?, NOW())";

        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement checkStmt = conn.prepareStatement(checkSql)) {

            checkStmt.setString(1, patientId);
            checkStmt.setString(2, prescriptionText);
            ResultSet rs = checkStmt.executeQuery();

            if (rs.next() && rs.getInt(1) == 0) {
                try (PreparedStatement insertStmt = conn.prepareStatement(insertSql)) {
                    insertStmt.setString(1, patientId);
                    insertStmt.setString(2, prescriptionText);
                    insertStmt.setString(3, doctorId);
                    insertStmt.executeUpdate();
                }
            }

        } catch (SQLException e) {
            showAlert("Database Error", e.getMessage());
        }
    }

    @FXML
    private void handleCancel(javafx.event.ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/smarthospitalmanagmentsystem/views/PatientRecords.fxml"));
            Parent root = loader.load();

            PatientRecordsController controller = loader.getController();
            controller.setDoctorId(doctorId);

            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            showAlert("Navigation Error", "Could not load PatientRecords page.");
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
