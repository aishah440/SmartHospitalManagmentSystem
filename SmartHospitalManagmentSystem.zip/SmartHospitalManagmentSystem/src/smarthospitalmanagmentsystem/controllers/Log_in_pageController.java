package smarthospitalmanagmentsystem.controllers;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import smarthospitalmanagmentsystem.DB.DatabaseConnection;
import smarthospitalmanagmentsystem.controllers.DoctorPageController;
import smarthospitalmanagmentsystem.controllers.PatientPageController;
import smarthospitalmanagmentsystem.controllers.Admin_PageController;

public class Log_in_pageController implements Initializable {

    private Stage stage;
    private Scene scene;
    private Parent root;

    @FXML
    private TextField Idfield;
    @FXML
    private TextField usernameField;
    @FXML
    private PasswordField passwordField;
    @FXML
    private Button loginBtn;
    @FXML
    private Button ExitBtn;
    @FXML
    private ComboBox<String> UserType;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        UserType.getItems().addAll("Doctor", "Patient", "Admin");
    }

    @FXML
    private void handleExit() {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Exit Confirmation");
        alert.setHeaderText(null);
        alert.setContentText("Are you sure you want to exit?");
        if (alert.showAndWait().orElse(ButtonType.CANCEL) == ButtonType.OK) {
            stage = (Stage) ExitBtn.getScene().getWindow();
            stage.close();
        }
    }

    @FXML
    private void handleLogin() {
        String id = Idfield.getText().trim();
        String password = passwordField.getText().trim();
        String userType = UserType.getValue();

        if (id.isEmpty() || password.isEmpty() || userType == null) {
            showAlert(Alert.AlertType.ERROR, "Login Error", "All fields must be filled!");
            return;
        }

        try {
            Connection conn = DatabaseConnection.getInstance().getConnection();

            String sql = "SELECT * FROM users WHERE id = ? AND password = ? AND userType = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, id);
            stmt.setString(2, password);
            stmt.setString(3, userType);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                String name = rs.getString("name");

                String logSql = "INSERT INTO logged_users (id, name, userType) VALUES (?, ?, ?)";
                PreparedStatement logStmt = conn.prepareStatement(logSql);
                logStmt.setString(1, id);
                logStmt.setString(2, name);
                logStmt.setString(3, userType);
                logStmt.executeUpdate();

                showAlert(Alert.AlertType.INFORMATION, "Login Successful", "Welcome " + userType + " " + name);
                loadDashboard(userType, id);
            } else {
                showAlert(Alert.AlertType.ERROR, "Login Failed", "Invalid credentials. Please try again.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Database Error", "Could not connect to the database.");
        }
    }

    private void loadDashboard(String userType, String userId) {
        String fxmlFile = "";
        switch (userType) {
            case "Doctor":
                fxmlFile = "/smarthospitalmanagmentsystem/views/DoctorPage.fxml";
                break;
            case "Patient":
                fxmlFile = "/smarthospitalmanagmentsystem/views/Patient page.fxml";
                break;
            case "Admin":
                fxmlFile = "/smarthospitalmanagmentsystem/views/Admin_Page.fxml";
                break;
        }

        if (!fxmlFile.isEmpty()) {
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFile));
                Parent root = loader.load();

                switch (userType) {
                    case "Patient":
                        PatientPageController patientController = loader.getController();
                        patientController.setPatientId(userId);
                        break;
                    case "Doctor":
                        DoctorPageController doctorController = loader.getController();
                        doctorController.setDoctorId(userId);
                        break;
                    case "Admin":
                        Admin_PageController adminController = loader.getController();
                        adminController.setAdminId(userId);
                        break;
                }

                Stage stage = (Stage) loginBtn.getScene().getWindow();
                stage.setScene(new Scene(root));
                stage.show();
            } catch (IOException e) {
                e.printStackTrace();
                showAlert(Alert.AlertType.ERROR, "Error", "Failed to load dashboard.");
            }
        }
    }

    private void showAlert(Alert.AlertType type, String title, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        DialogPane dialogPane = alert.getDialogPane();
        dialogPane.getStylesheets().add(getClass().getResource("/smarthospitalmanagmentsystem/resources/css/alert-style.css").toExternalForm());
        dialogPane.getStyleClass().add("custom-alert");

        alert.showAndWait();
    }
}
