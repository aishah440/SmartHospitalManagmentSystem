package smarthospitalmanagmentsystem.controllers;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import smarthospitalmanagmentsystem.DB.DatabaseConnection;
import smarthospitalmanagmentsystem.models.Appointment;
import smarthospitalmanagmentsystem.models.Doctor;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.scene.Node;
import javafx.beans.property.SimpleStringProperty;

public class ViewAppointmentsController implements Initializable {

    @FXML
    private TableView<Appointment> appointmentTable;

    @FXML
    private TableColumn<Appointment, String> titleCol;

    @FXML
    private TableColumn<Appointment, String> doctorCol;

    @FXML
    private TableColumn<Appointment, Date> dateCol;

    @FXML
    private TableColumn<Appointment, String> timeCol;

    @FXML
    private TableColumn<Appointment, Double> priceCol;

    @FXML
    private Button backButton;

    private String patientId;

    public void setPatientId(String id) {
        this.patientId = id;
        loadAppointments();
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        titleCol.setCellValueFactory(new PropertyValueFactory<>("title"));

        doctorCol.setCellValueFactory(cellData
                -> new SimpleStringProperty(cellData.getValue().getDoctor() != null ? cellData.getValue().getDoctor().getName() : "")
        );

        dateCol.setCellValueFactory(new PropertyValueFactory<>("date"));
        timeCol.setCellValueFactory(new PropertyValueFactory<>("time"));
        priceCol.setCellValueFactory(new PropertyValueFactory<>("price"));
    }

    private void loadAppointments() {
        List<Appointment> appointments = new ArrayList<>();
        String query = """
            SELECT a.title, a.date, a.time, a.price,
                   d.id AS doctor_id, d.name AS doctor_name
            FROM appointments a
            JOIN doctors d ON a.doctor_id = d.id
            WHERE a.patient_id = ?
        """;

        try ( Connection conn = DatabaseConnection.getInstance().getConnection();  PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, patientId);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                String title = rs.getString("title");
                String doctorId = rs.getString("doctor_id");
                String doctorName = rs.getString("doctor_name");
                LocalDate date = rs.getDate("date").toLocalDate();
                String time = rs.getString("time");
                double price = rs.getDouble("price");

                Doctor doctor = new Doctor(doctorId, doctorName);
                appointments.add(new Appointment(null, doctor, date, time, price, title));
            }

            appointmentTable.getItems().setAll(appointments);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleBack(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/smarthospitalmanagmentsystem/views/Patient page.fxml"));
        Parent root = loader.load();

        PatientPageController controller = loader.getController();
        controller.setPatientId(patientId); // Re-pass patient ID

        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }
}
